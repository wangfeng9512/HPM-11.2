/* ====================================================================================================================

  The copyright in this software is being made available under the License included below.
  This software may be subject to other third party and contributor rights, including patent rights, and no such
  rights are granted under this license.

  Copyright (c) 2018, HUAWEI TECHNOLOGIES CO., LTD. All rights reserved.
  Copyright (c) 2018, SAMSUNG ELECTRONICS CO., LTD. All rights reserved.
  Copyright (c) 2018, PEKING UNIVERSITY SHENZHEN GRADUATE SCHOOL. All rights reserved.
  Copyright (c) 2018, PENGCHENG LABORATORY. All rights reserved.

  Redistribution and use in source and binary forms, with or without modification, are permitted only for
  the purpose of developing standards within Audio and Video Coding Standard Workgroup of China (AVS) and for testing and
  promoting such standards. The following conditions are required to be met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and
      the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
      the following disclaimer in the documentation and/or other materials provided with the distribution.
    * The name of HUAWEI TECHNOLOGIES CO., LTD. or SAMSUNG ELECTRONICS CO., LTD. may not be used to endorse or promote products derived from
      this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

* ====================================================================================================================
*/

#ifndef _DEC_DEF_H_
#define _DEC_DEF_H_

#include "com_def.h"
#include "dec_bsr.h"

/* decoder magic code */
#define DEC_MAGIC_CODE          0x45565944 /* EVYD */

/*****************************************************************************
* ALF structure
*****************************************************************************/
typedef struct _DEC_ALF_VAR
{
    int          **filter_coeff_sym;
    int            var_ind_tab[NO_VAR_BINS];
#if ALF_IMP
    pel          **var_img_arr[ITER_NUM];
#endif
    pel          **var_img;
    BOOL         **alf_lcu_enabled;
    ALF_PARAM    **alf_picture_param;
} DEC_ALF_VAR;

/*****************************************************************************
 * SBAC structure
 *****************************************************************************/
typedef struct _DEC_SBAC
{
    u32            range;
    u32            value;
    int            bits_Needed;
    u32            prev_bytes;
    COM_SBAC_CTX   ctx;
} DEC_SBAC;

/*****************************************************************************
 * CORE information used for decoding process.
 *
 * The variables in this structure are very often used in decoding process.
 *****************************************************************************/
typedef struct _DEC_CORE
{
    COM_MODE       mod_info_curr;
    /* neighbor pixel buffer for intra prediction */
    pel            nb[N_C][N_REF][MAX_CU_SIZE * 3];

    


    /* QP for Luma of current encoding MB */
    int             qp_y;
    /* QP for Chroma of current encoding MB */
    int             qp_u;
    int             qp_v;
#if PMC || EPMC
    int             qp_v_pmc;
#endif

    /************** current LCU *************/
    /* address of current LCU,  */
    int            lcu_num;
    /* X address of current LCU */
    int            x_lcu;
    /* Y address of current LCU */
    int            y_lcu;
    /* left pel position of current LCU */
    int            x_pel;
    /* top pel position of current LCU */
    int            y_pel;
    /* split mode map for current LCU */

    s8             split_mode[MAX_CU_DEPTH][NUM_BLOCK_SHAPE][MAX_CU_CNT_IN_LCU];
    /* platform specific data, if needed */
    void          *pf;

    COM_MOTION     motion_cands[ALLOWED_HMVP_NUM];
#if BGC
    s8             bgc_flag_cands[ALLOWED_HMVP_NUM];
    s8             bgc_idx_cands[ALLOWED_HMVP_NUM];
#endif
    s8             cnt_hmvp_cands;

#if IBC_BVP
    COM_BLOCK_MOTION     block_motion_cands[ALLOWED_HBVP_NUM];
    s8                   cnt_hbvp_cands;
    int                  hbvp_empty_flag;
#endif

#if MVAP
    COM_MOTION     best_cu_mvfield[(MAX_CU_SIZE >> 2) * (MAX_CU_SIZE >> 2)];
    COM_MOTION     tmp_cu_mvfield[(MAX_CU_SIZE >> 2) * (MAX_CU_SIZE >> 2)];
    COM_MOTION     neighbor_motions[MAX_CU_SIZE + 4];
    s32            valid_mvap_index[ALLOWED_MVAP_NUM];
    s32            valid_mvap_num;
    s32            mvap_mode;
    BOOL           mvap_flag;
#endif
#if SUB_TMVP
    BOOL sbTmvp_flag;
    COM_MOTION sbTmvp[SBTMVP_NUM];
#endif
#if FIMC
    COM_CNTMPM     cntmpm_cands;
#endif
#if USE_SP
    s8             n_offset_num;
    COM_MOTION     n_recent_offset[SP_RECENT_CANDS];
    u8             n_pv_num;
    COM_MOTION     n_recent_pv[MAX_SRB_PRED_SIZE];
    u8             n_recent_all_comp_flag[MAX_SRB_PRED_SIZE];
#if EVSDPBBF
    u8             n_recent_dpb_re[MAX_SRB_PRED_SIZE];
#else
    pel            n_recent_dpb[N_C][MAX_SRB_PRED_SIZE];
#endif
    u8             n_recent_dpb_idx[MAX_SRB_PRED_SIZE];
#if !EVS_FIX
    u8             n_recent_cuS_flag[MAX_SRB_PRED_SIZE];
#endif
#endif
#if ETMVP
    COM_MOTION    best_etmvp_mvfield[(MAX_CU_SIZE >> 2) * (MAX_CU_SIZE >> 2)];
#endif
} DEC_CORE;

/******************************************************************************
 * CONTEXT used for decoding process.
 *
 * All have to be stored are in this structure.
 *****************************************************************************/
typedef struct _DEC_CTX DEC_CTX;
struct _DEC_CTX
{
    COM_INFO              info;
    /* magic code */
    u32                   magic;
    /* DEC identifier */
    DEC                   id;
    /* CORE information used for fast operation */
    DEC_CORE             *core;
    /* current decoding bitstream */
    COM_BSR               bs;

    /* decoded picture buffer management */
    COM_PM                dpm;
    /* create descriptor */
    DEC_CDSC              cdsc;

    /* current decoded (decoding) picture buffer */
    COM_PIC              *pic;
#if USE_SP
    pel                   dpb_evs[N_C][MAX_SRB_PRED_SIZE];
#endif
    /* SBAC */
    DEC_SBAC              sbac_dec;
    u8                    init_flag;

    COM_MAP               map;
#if CHROMA_NOT_SPLIT
    u8                    tree_status;
#endif
#if MODE_CONS
    u8                    cons_pred_mode;
#endif

    /* total count of remained LCU for decoding one picture. if a picture is
    decoded properly, this value should reach to zero */
    int                   lcu_cnt;

    int                 **edge_filter[LOOPFILTER_DIR_TYPE];

    COM_PIC              *pic_sao;
    SAO_STAT_DATA        ***sao_stat_data; //[SMB][comp][types]
    SAO_BLK_PARAM         **sao_blk_params; //[SMB][comp]
    SAO_BLK_PARAM         **rec_sao_blk_params;//[SMB][comp]

#if ESAO
    COM_PIC              *pic_esao;  //rec buff after deblock filter
    ESAO_BLK_PARAM          pic_esao_params[N_C];//comp]
    ESAO_FUNC_POINTER       func_esao_block_filter;
#endif

#if CCSAO
#if CCSAO_ENHANCEMENT
    COM_PIC              *pic_ccsao[2];
#else
    COM_PIC              *pic_ccsao;
#endif
#if !CCSAO_PH_SYNTAX
    CCSAO_BLK_PARAM       pic_ccsao_params[N_C-1];
#endif
    CCSAO_FUNC_POINTER    ccsao_func_ptr;
#endif

    COM_PIC              *pic_alf_Dec;
    COM_PIC              *pic_alf_Rec;
    int                   pic_alf_on[N_C];
    int                ***coeff_all_to_write_alf;
    DEC_ALF_VAR            *dec_alf;

    u8                    ctx_flags[NUM_CNID];

    /**************************************************************************/
    /* current slice number, which is increased whenever decoding a slice.
    when receiving a slice for new picture, this value is set to zero.
    this value can be used for distinguishing b/w slices */
    u16                   slice_num;
    /* last coded intra picture's presentation temporal reference */
    int                   last_intra_ptr;
    /* current picture's decoding temporal reference */
    int                   dtr;
    /* previous picture's decoding temporal reference low part */
    int                   dtr_prev_low;
    /* previous picture's decoding temporal reference high part */
    int                   dtr_prev_high;
    /* current picture's presentation temporal reference */
    int                   ptr;
    /* the number of currently decoded pictures */
    int                   pic_cnt;
    /* picture buffer allocator */
    PICBUF_ALLOCATOR      pa;
    /* bitstream has an error? */
    u8                    bs_err;
    /* reference picture (0: foward, 1: backward) */
    COM_REFP              refp[MAX_NUM_REF_PICS][REFP_NUM];
    /* flag for picture signature enabling */
    u8                    use_pic_sign;
    /* picture signature (MD5 digest 128bits) */
    u8                    pic_sign[16];
    /* flag to indicate picture signature existing or not */
    u8                    pic_sign_exist;

#if PATCH
    int                   patch_column_width[64];
    int                   patch_row_height[128];
    PATCH_INFO           *patch;
#endif

    u8                   *wq[2];
#if CUDQP
    COM_CU_QP_GROUP       cu_qp_group;
#endif
#if EXTENSION_USER_DATA
    COM_EXTENSION_DATA   dec_ctx_extension_data;
#endif
};

/* prototypes of internal functions */
int  dec_pull_frm(DEC_CTX *ctx, COM_IMGB **imgb, int state /*0: STATE_DECODING, 1: STATE_BUMPING*/);
int  dec_ready(DEC_CTX * ctx);
void dec_flush(DEC_CTX * ctx);
int  dec_cnk(DEC_CTX * ctx, COM_BITB * bitb, DEC_STAT * stat);

int  dec_deblock_avs2(DEC_CTX * ctx);

int  dec_sao_avs2(DEC_CTX * ctx);
void read_param_sao_one_lcu(DEC_CTX* ctx, int y_pel, int x_pel,
                         SAO_BLK_PARAM *sao_blk_param, SAO_BLK_PARAM *rec_sao_blk_param);
void read_sao_lcu(DEC_CTX* ctx, int lcu_pos, int pix_y, int pix_x, int smb_pix_width, int smb_pix_height,
                  SAO_BLK_PARAM *sao_cur_param, SAO_BLK_PARAM *rec_sao_cur_param);

#if ESAO
int  dec_esao(DEC_CTX * ctx);
#endif

#if CCSAO
int  dec_ccsao(DEC_CTX *ctx);
#endif

int  dec_pic(DEC_CTX * ctx, DEC_CORE * core, COM_SQH *sqh, COM_PIC_HEADER * ph, COM_SH_EXT * shext);
#if PATCH
void de_copy_lcu_scu(u32 * scu_temp, u32 * scu_best, s8(*refi_temp)[REFP_NUM], s8(*refi_best)[REFP_NUM], s16(*mv_temp)[REFP_NUM][MV_D],
                     s16(*mv_best)[REFP_NUM][MV_D], u32 *cu_mode_temp, u32 *cu_mode_best, PATCH_INFO * patch, int pic_width, int pic_height
#if USE_SP
                     , u8 * usp_temp, u8 * usp_best
#endif
);
void dec_set_patch_idx(s8 *map_patch_idx, PATCH_INFO * patch, int pic_width, int pic_height);
#endif
#include "dec_util.h"
#include "dec_eco.h"
#include "com_picman.h"

#endif /* _DEC_DEF_H_ */
